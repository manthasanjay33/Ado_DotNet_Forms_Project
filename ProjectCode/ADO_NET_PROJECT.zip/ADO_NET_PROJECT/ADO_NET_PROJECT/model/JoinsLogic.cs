﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows.Forms;
using System.Data.SqlServerCe;

namespace ADO_NET_PROJECT.model
{
    class JoinsLogic
    {

        private string connStr = ConfigurationManager.ConnectionStrings["db5"].ConnectionString;




        public DataTable getCommonDetails()
        {

            DataTable table = new DataTable();

            SqlConnection conn = new SqlConnection(connStr);

            string query = "select E.EMPID,E.EMPNAME,E.SALARY,D.DEPTID,D.DEPTNAME,D.DEPTLOC,D.MGR_ID FROM EMPLOYEE E INNER JOIN DEPT D ON E.DEPTID=D.DEPTID";

         
            try
            {
                conn.Open();
                
                SqlCommand cmd = new SqlCommand(query,conn);

                cmd.ExecuteNonQuery();

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                adapter.Fill(table);

                MessageBox.Show("data retrieved successfully");


            }
            catch (Exception)
            {
                MessageBox.Show("failed to connect");
            }
            finally
            {
                conn.Close();
            }

            return table;

        }

    }
}
